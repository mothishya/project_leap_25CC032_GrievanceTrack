package com.example.grievance_track.service;

import com.example.grievance_track.entity.Grievance;
import com.example.grievance_track.entity.Rating;
import com.example.grievance_track.exception.ResourceNotFoundException;
import com.example.grievance_track.repository.GrievanceRepository;
import com.example.grievance_track.repository.RatingRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
public class RatingService {

    private final RatingRepository ratingRepository;
    private final GrievanceRepository grievanceRepository;

    public RatingService(
            RatingRepository ratingRepository,
            GrievanceRepository grievanceRepository) {

        this.ratingRepository = ratingRepository;
        this.grievanceRepository = grievanceRepository;
    }

    public Rating createRating(Long grievanceId, Rating rating) {

        Grievance grievance = grievanceRepository.findById(grievanceId)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Grievance not found with id: " + grievanceId
                        )
                );

        if (!"RESOLVED".equalsIgnoreCase(grievance.getStatus())) {
            throw new IllegalStateException(
                    "Rating can be given only after grievance is resolved"
            );
        }

        rating.setGrievance(grievance);
        rating.setCreatedAt(LocalDateTime.now());

        return ratingRepository.save(rating);
    }
}