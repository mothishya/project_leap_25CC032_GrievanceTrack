package com.example.grievance_track.service;

import com.example.grievance_track.entity.Category;
import com.example.grievance_track.entity.Department;
import com.example.grievance_track.entity.Escalation;
import com.example.grievance_track.entity.Grievance;
import com.example.grievance_track.exception.ResourceNotFoundException;
import com.example.grievance_track.repository.CategoryRepository;
import com.example.grievance_track.repository.DepartmentRepository;
import com.example.grievance_track.repository.EscalationRepository;
import com.example.grievance_track.repository.GrievanceRepository;
import org.springframework.stereotype.Service;



import java.time.LocalDateTime;
import java.util.List;

@Service
public class GrievanceService {

    private final GrievanceRepository grievanceRepository;
    private final CategoryRepository categoryRepository;
    private final DepartmentRepository departmentRepository;
    private final EscalationRepository escalationRepository;

    public GrievanceService(
            GrievanceRepository grievanceRepository,
            CategoryRepository categoryRepository,
            DepartmentRepository departmentRepository,
            EscalationRepository escalationRepository) {

        this.grievanceRepository = grievanceRepository;
        this.categoryRepository = categoryRepository;
        this.departmentRepository = departmentRepository;
        this.escalationRepository = escalationRepository;
    }

    public Grievance saveGrievance(Grievance grievance) {

        // Set initial status
        grievance.setStatus("PENDING");

        // Set creation time
        grievance.setCreatedAt(LocalDateTime.now());

        // Set SLA deadline - 48 hours
        grievance.setSlaDeadline(
                LocalDateTime.now().plusHours(48)
        );

        // Get category
        if (grievance.getCategory() != null &&
                grievance.getCategory().getId() != null) {

            Category category = categoryRepository
                    .findById(grievance.getCategory().getId())
                    .orElseThrow(() ->
                            new RuntimeException("Category not found"));

            grievance.setCategory(category);

            // Automatically assign department
            Department department =
                    assignDepartment(category.getName());

            grievance.setDepartment(department);
        }

        return grievanceRepository.save(grievance);
    }

    private Department assignDepartment(String categoryName) {

        String departmentName;

        switch (categoryName.toLowerCase()) {

            case "infrastructure":
                departmentName = "Maintenance";
                break;

            case "academic":
                departmentName = "Academic Affairs";
                break;

            case "hostel":
                departmentName = "Hostel Administration";
                break;

            case "transport":
                departmentName = "Transport";
                break;

            default:
                departmentName = "General Administration";
        }

        return departmentRepository
                .findAll()
                .stream()
                .filter(d ->
                        d.getName()
                                .equalsIgnoreCase(departmentName))
                .findFirst()
                .orElseThrow(() ->
                        new RuntimeException(
                                "Department not found: "
                                        + departmentName));
    }

    public List<Grievance> getAllGrievances() {
        return grievanceRepository.findAll();
    }

    public Grievance getGrievanceById(Long id) {

        return grievanceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Grievance not found with id: " + id
                        )
                );
    }
    public void deleteGrievance(Long id) {
        grievanceRepository.deleteById(id);
    }

    public Grievance updateStatus(Long id, String status) {

        Grievance grievance = grievanceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Grievance not found with id: " + id
                        )
                );

        grievance.setStatus(status.toUpperCase());

        return grievanceRepository.save(grievance);
    }
    public Escalation escalateGrievance(Long id) {

        Grievance grievance = grievanceRepository.findById(id)
                .orElseThrow(() ->
                        new ResourceNotFoundException(
                                "Grievance not found with id: " + id
                        )
                );

        if ("RESOLVED".equalsIgnoreCase(grievance.getStatus())
                || "CLOSED".equalsIgnoreCase(grievance.getStatus())) {

            throw new RuntimeException(
                    "Resolved or closed grievance cannot be escalated"
            );
        }

        Escalation escalation = new Escalation();

        escalation.setGrievance(grievance);
        escalation.setReason("SLA deadline exceeded");
        escalation.setStatus("ESCALATED");

        return escalationRepository.save(escalation);
    }
}