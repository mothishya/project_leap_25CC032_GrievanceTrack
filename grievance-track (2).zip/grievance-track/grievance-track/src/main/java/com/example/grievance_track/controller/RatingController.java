package com.example.grievance_track.controller;

import com.example.grievance_track.entity.Rating;
import com.example.grievance_track.service.RatingService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ratings")
public class RatingController {

    private final RatingService ratingService;

    public RatingController(RatingService ratingService) {
        this.ratingService = ratingService;
    }

    @PostMapping("/grievance/{grievanceId}")
    @ResponseStatus(HttpStatus.CREATED)
    public Rating createRating(
            @PathVariable Long grievanceId,
            @Valid @RequestBody Rating rating) {

        return ratingService.createRating(grievanceId, rating);
    }
}